import fs from 'node:fs';
const src=fs.readFileSync(new URL('../backend/construite-backend/src/config/roles.js', import.meta.url),'utf8');
for (const [portal, roles] of Object.entries({admin:['DUENO','GERENTE'],cliente:['DUENO','ADMINISTRADOR_CONSORCIO'],personal:['DUENO','GERENTE','ENCARGADO','TRABAJADOR']})) {
  const line=src.split('\n').find(x=>x.includes(`${portal}: [`));
  if(!line) throw new Error(`portal ausente: ${portal}`);
  for(const role of roles) if(!src.includes(`ROLES.${role}`)) throw new Error(`rol ausente: ${role}`);
}
console.log('PASS role matrix source');
