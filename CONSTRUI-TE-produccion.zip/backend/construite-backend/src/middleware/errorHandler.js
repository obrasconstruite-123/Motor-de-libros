// Manejador de errores centralizado. Evita filtrar stack traces / detalles
// internos al cliente en produccion.
function errorHandler(err, req, res, next) {
  console.error(err);
  const status = err.status || 500;
  const esProd = process.env.NODE_ENV === "production";
  res.status(status).json({
    error: esProd ? "Error interno" : err.message,
  });
}

module.exports = errorHandler;
