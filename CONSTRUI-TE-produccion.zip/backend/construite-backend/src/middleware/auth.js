const { verificarToken } = require("../utils/jwt");
const { puedeAcceder } = require("../config/roles");
const prisma = require("../config/prisma");

// 1) Verifica que venga un JWT valido y carga el usuario fresco desde la DB
//    (fresco, no solo lo que dice el token, para que un usuario desactivado
//    quede afuera al instante aunque su token todavia no haya vencido).
async function requireAuth(req, res, next) {
  try {
    const header = req.headers.authorization || "";
    const token = header.startsWith("Bearer ") ? header.slice(7) : null;
    if (!token) return res.status(401).json({ error: "No autenticado" });

    const payload = verificarToken(token);
    const usuario = await prisma.usuario.findUnique({ where: { id: payload.sub } });
    if (!usuario || !usuario.activo) return res.status(401).json({ error: "Usuario invalido o inactivo" });

    // req.user es lo unico que el resto de la app debe usar para decidir que mostrar
    req.user = {
      id: usuario.id,
      rol: usuario.rol,
      administracionId: usuario.administracionId,
      trabajadorId: usuario.trabajadorId,
    };
    next();
  } catch (err) {
    return res.status(401).json({ error: "Token invalido o vencido" });
  }
}

// 2) Verifica que el rol del usuario tenga permitido entrar a este portal.
//    Se usa una vez por grupo de rutas (admin/cliente/personal), no por endpoint.
function requirePortal(portal) {
  return (req, res, next) => {
    if (!req.user) return res.status(401).json({ error: "No autenticado" });
    if (!puedeAcceder(req.user.rol, portal)) {
      return res.status(403).json({ error: `Tu rol no tiene acceso al portal '${portal}'` });
    }
    next();
  };
}

// 3) Ademas del portal, algunas rutas requieren un rol puntual dentro de ese portal
//    (ej: solo DUENO puede borrar una administracion, GERENTE no).
function requireRole(...rolesPermitidos) {
  return (req, res, next) => {
    if (!req.user) return res.status(401).json({ error: "No autenticado" });
    if (!rolesPermitidos.includes(req.user.rol)) {
      return res.status(403).json({ error: "No tenes permiso para esta accion" });
    }
    next();
  };
}

module.exports = { requireAuth, requirePortal, requireRole };
