const prisma = require("../../config/prisma");

// Helper: calcula presupuesto total y costo real igual que hace el frontend.
// Vive del lado admin porque solo el admin tiene permitido ver el desglose completo.
function calcularFinanzasObra(obra) {
  const base =
    Number(obra.presupuestoMateriales) +
    Number(obra.presupuestoManoObra) +
    Number(obra.presupuestoSubcontratos);
  const margenMonto = base * (Number(obra.margenPct) / 100);
  const subtotal = base + margenMonto;
  const ivaMonto = subtotal * (Number(obra.ivaPct) / 100);
  const totalPresupuesto = subtotal + ivaMonto;

  const costoMaterialesReal = (obra.materiales || []).reduce(
    (s, m) => s + Number(m.cantidadReal || 0) * Number(m.precioReal || 0),
    0
  );
  const costoPersonalReal = (obra.partesDiarios || []).reduce((s, p) => {
    if (!p.horaInicio || !p.horaFin) return s;
    const horas = (new Date(p.horaFin) - new Date(p.horaInicio)) / 1000 / 3600;
    const costoHora = Number(p.trabajador?.costoHora || 0);
    return s + horas * costoHora;
  }, 0);
  const cobrado = (obra.pagos || []).reduce((s, p) => s + Number(p.monto), 0);

  return {
    totalPresupuesto,
    costoReal: costoMaterialesReal + costoPersonalReal,
    gananciaEstimada: totalPresupuesto - (costoMaterialesReal + costoPersonalReal),
    cobrado,
    saldo: Math.max(0, totalPresupuesto - cobrado),
  };
}

// GET /api/admin/dashboard
async function dashboard(req, res) {
  const [administraciones, obras] = await Promise.all([
    prisma.administracion.findMany({ select: { estado: true } }),
    prisma.obra.findMany({
      include: { materiales: true, pagos: true, partesDiarios: { include: { trabajador: true } } },
    }),
  ]);

  const activas = obras.filter((o) => !["Terminada", "Cancelada"].includes(o.estado));
  const finanzas = obras.reduce(
    (acc, o) => {
      const f = calcularFinanzasObra(o);
      acc.facturado += f.totalPresupuesto;
      acc.cobrado += f.cobrado;
      acc.ganancia += f.gananciaEstimada;
      return acc;
    },
    { facturado: 0, cobrado: 0, ganancia: 0 }
  );

  res.json({
    obrasActivas: activas.length,
    presupuestosPendientes: obras.filter((o) => o.estado === "Presupuesto").length,
    clientes: administraciones.filter((a) => a.estado === "Cliente").length,
    prospectos: administraciones.filter((a) => a.estado === "Prospecto").length,
    finanzas,
  });
}

// ---- Administraciones (CRM) ----

async function listarAdministraciones(req, res) {
  const administraciones = await prisma.administracion.findMany({
    include: { consorcios: true },
    orderBy: { createdAt: "desc" },
  });
  res.json(administraciones);
}

async function crearAdministracion(req, res) {
  const { nombre, responsable, telefono, whatsapp, email, estado, notas } = req.body;
  if (!nombre) return res.status(400).json({ error: "nombre es requerido" });
  const admin = await prisma.administracion.create({
    data: { nombre, responsable, telefono, whatsapp, email, estado, notas },
  });
  res.status(201).json(admin);
}

// ---- Obras ----

async function listarObras(req, res) {
  const obras = await prisma.obra.findMany({
    include: {
      consorcio: { include: { administracion: true } },
      materiales: true,
      pagos: true,
      asignaciones: { include: { trabajador: true } },
      partesDiarios: { include: { trabajador: true } },
    },
    orderBy: { createdAt: "desc" },
  });
  res.json(obras.map((o) => ({ ...o, finanzas: calcularFinanzasObra(o) })));
}

async function crearObra(req, res) {
  const { numero, consorcioId, descripcion, presupuestoMateriales, presupuestoManoObra, presupuestoSubcontratos, margenPct, ivaPct } = req.body;
  if (!numero || !consorcioId) return res.status(400).json({ error: "numero y consorcioId son requeridos" });
  const obra = await prisma.obra.create({
    data: {
      numero,
      consorcioId: Number(consorcioId),
      descripcion,
      presupuestoMateriales: presupuestoMateriales || 0,
      presupuestoManoObra: presupuestoManoObra || 0,
      presupuestoSubcontratos: presupuestoSubcontratos || 0,
      margenPct: margenPct ?? 20,
      ivaPct: ivaPct ?? 21,
    },
  });
  res.status(201).json(obra);
}

// PATCH /api/admin/obras/:id/estado  { estado, avancePct? }
async function actualizarEstadoObra(req, res) {
  const { id } = req.params;
  const { estado, avancePct } = req.body;
  const obra = await prisma.obra.update({
    where: { id: Number(id) },
    data: { estado, ...(avancePct !== undefined ? { avancePct } : {}) },
  });
  res.json(obra);
}

// POST /api/admin/incidencias/:id/convertir-en-obra
// Toma una incidencia reportada por el cliente y la transforma en obra + presupuesto,
// tal como pide el flujo del documento: solicitud -> visita -> presupuesto -> obra.
async function convertirIncidenciaEnObra(req, res) {
  const { id } = req.params;
  const incidencia = await prisma.incidencia.findUnique({ where: { id: Number(id) } });
  if (!incidencia) return res.status(404).json({ error: "Incidencia no encontrada" });

  const numero = `${new Date().getFullYear()}-${String(Date.now()).slice(-5)}`;
  const obra = await prisma.obra.create({
    data: { numero, consorcioId: incidencia.consorcioId, descripcion: incidencia.problema, estado: "Presupuesto" },
  });
  await prisma.incidencia.update({ where: { id: incidencia.id }, data: { estado: "En revision", obraId: obra.id } });
  res.status(201).json(obra);
}

module.exports = {
  dashboard,
  listarAdministraciones,
  crearAdministracion,
  listarObras,
  crearObra,
  actualizarEstadoObra,
  convertirIncidenciaEnObra,
};
