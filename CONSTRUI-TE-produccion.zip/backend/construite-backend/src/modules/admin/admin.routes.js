const router = require("express").Router();
const { requireAuth, requirePortal, requireRole } = require("../../middleware/auth");
const { ROLES } = require("../../config/roles");
const ctrl = require("./admin.controller");

// Todo lo que cuelga de aca requiere: estar logueado + tener acceso al portal 'admin'.
// Es la unica linea de defensa que hace falta a nivel de ruta; el resto del aislamiento
// (que un cliente jamas llegue a estos endpoints) ya esta garantizado porque ADMINISTRADOR_CONSORCIO
// y TRABAJADOR ni siquiera pasan el requirePortal('admin').
router.use(requireAuth, requirePortal("admin"));

router.get("/dashboard", ctrl.dashboard);

router.get("/administraciones", ctrl.listarAdministraciones);
router.post("/administraciones", ctrl.crearAdministracion);

router.get("/obras", ctrl.listarObras);
router.post("/obras", ctrl.crearObra);
router.patch("/obras/:id/estado", ctrl.actualizarEstadoObra);

// Ejemplo de accion restringida a un rol puntual dentro del portal admin:
// un GERENTE puede operar el dia a dia pero no dar de baja cuentas por cobrar grandes, etc.
// (dejado como ejemplo del patron; ajustar segun las reglas de negocio reales)
router.post("/incidencias/:id/convertir-en-obra", requireRole(ROLES.DUENO, ROLES.GERENTE), ctrl.convertirIncidenciaEnObra);

module.exports = router;
