const prisma = require("../../config/prisma");
const { compararPassword } = require("../../utils/hash");
const { firmarToken } = require("../../utils/jwt");
const { PORTAL_ACCESS } = require("../../config/roles");

// POST /api/auth/login
// Unico punto de entrada para los 3 portales. El frontend de cada portal
// (admin / cliente / personal) llama a este mismo endpoint; lo que cambia
// es a que rutas puede acceder despues, segun el rol devuelto.
async function login(req, res) {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ error: "Falta email o password" });
  }

  const usuario = await prisma.usuario.findUnique({ where: { email } });
  if (!usuario || !usuario.activo) {
    return res.status(401).json({ error: "Credenciales invalidas" });
  }

  const passwordOk = await compararPassword(password, usuario.passwordHash);
  if (!passwordOk) {
    return res.status(401).json({ error: "Credenciales invalidas" });
  }

  const token = firmarToken({
    sub: usuario.id,
    rol: usuario.rol,
    administracionId: usuario.administracionId,
    trabajadorId: usuario.trabajadorId,
  });

  res.json({
    token,
    usuario: {
      id: usuario.id,
      nombre: usuario.nombre,
      email: usuario.email,
      rol: usuario.rol,
    },
    // le decimos al frontend a que portales puede entrar, para que
    // la app cliente/personal/admin sepa que pantalla mostrar despues del login
    portalesDisponibles: Object.entries(PORTAL_ACCESS)
      .filter(([, roles]) => roles.includes(usuario.rol))
      .map(([portal]) => portal),
  });
}

// GET /api/auth/me
async function me(req, res) {
  const usuario = await prisma.usuario.findUnique({
    where: { id: req.user.id },
    select: { id: true, nombre: true, email: true, rol: true, administracionId: true, trabajadorId: true },
  });
  res.json({ usuario });
}

module.exports = { login, me };
