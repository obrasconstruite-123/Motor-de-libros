const bcrypt = require("bcryptjs");

async function hashPassword(plano) {
  return bcrypt.hash(plano, 10);
}

async function compararPassword(plano, hash) {
  return bcrypt.compare(plano, hash);
}

module.exports = { hashPassword, compararPassword };
