// ============================================================================
// Matriz de permisos: que rol puede entrar a que portal.
// Esta es la traduccion en codigo de la tabla del documento de diseno.
// Se define en un solo lugar para que sea facil de auditar y de testear.
// ============================================================================

const ROLES = {
  DUENO: "DUENO",
  GERENTE: "GERENTE",
  ENCARGADO: "ENCARGADO",
  ADMINISTRADOR_CONSORCIO: "ADMINISTRADOR_CONSORCIO", // rol del lado cliente
  TRABAJADOR: "TRABAJADOR",                            // rol del lado personal
};

// portal -> lista de roles que pueden entrar a ese portal
const PORTAL_ACCESS = {
  admin: [ROLES.DUENO, ROLES.GERENTE],
  cliente: [ROLES.DUENO, ROLES.ADMINISTRADOR_CONSORCIO],
  personal: [ROLES.DUENO, ROLES.GERENTE, ROLES.ENCARGADO, ROLES.TRABAJADOR],
};

function puedeAcceder(rol, portal) {
  return (PORTAL_ACCESS[portal] || []).includes(rol);
}

module.exports = { ROLES, PORTAL_ACCESS, puedeAcceder };
