const { PrismaClient } = require("@prisma/client");

// Instancia unica de Prisma para toda la app (evita agotar conexiones a la DB)
const prisma = global.__prisma || new PrismaClient();
if (process.env.NODE_ENV !== "production") global.__prisma = prisma;

module.exports = prisma;
