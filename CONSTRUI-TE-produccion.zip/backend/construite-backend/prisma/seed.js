// Carga datos de ejemplo: un usuario por cada rol, para poder probar
// los 3 logins/portales de una. Correr con: npm run seed
const { PrismaClient } = require("@prisma/client");
const bcrypt = require("bcryptjs");

const prisma = new PrismaClient();

async function main() {
  const passwordHash = await bcrypt.hash("construite123", 10);

  // --- Dueño (ve los 3 portales) ---
  await prisma.usuario.upsert({
    where: { email: "dueno@construite.com" },
    update: {},
    create: { email: "dueno@construite.com", passwordHash, nombre: "Cristian (Dueño)", rol: "DUENO" },
  });

  // --- Administración / Cliente ---
  const administracion = await prisma.administracion.upsert({
    where: { id: 1 },
    update: {},
    create: {
      id: 1,
      nombre: "Administración González",
      responsable: "Marta González",
      whatsapp: "5491122334455",
      estado: "Cliente",
      consorcios: { create: [{ nombre: "Edificio Las Heras", direccion: "Las Heras 1234, CABA" }] },
    },
    include: { consorcios: true },
  });

  await prisma.usuario.upsert({
    where: { email: "cliente@gonzalez.com" },
    update: {},
    create: {
      email: "cliente@gonzalez.com",
      passwordHash,
      nombre: "Marta González",
      rol: "ADMINISTRADOR_CONSORCIO",
      administracionId: administracion.id,
    },
  });

  // --- Trabajador / Personal ---
  const trabajador = await prisma.trabajador.upsert({
    where: { id: 1 },
    update: {},
    create: { id: 1, nombre: "Juan Pérez", rolObra: "Oficial albañil", costoHora: 4500 },
  });

  await prisma.usuario.upsert({
    where: { email: "juan@construite.com" },
    update: {},
    create: {
      email: "juan@construite.com",
      passwordHash,
      nombre: "Juan Pérez",
      rol: "TRABAJADOR",
      trabajadorId: trabajador.id,
    },
  });

  // --- Una obra de ejemplo, con Juan asignado hoy ---
  const obra = await prisma.obra.upsert({
    where: { numero: "2026-0001" },
    update: {},
    create: {
      numero: "2026-0001",
      consorcioId: administracion.consorcios[0].id,
      descripcion: "Impermeabilización de terraza",
      estado: "En ejecución",
      avancePct: 40,
      presupuestoMateriales: 800000,
      presupuestoManoObra: 600000,
      presupuestoSubcontratos: 0,
    },
  });

  const inicioHoy = new Date();
  inicioHoy.setHours(0, 0, 0, 0);
  await prisma.asignacionObra.upsert({
    where: { obraId_trabajadorId_fecha: { obraId: obra.id, trabajadorId: trabajador.id, fecha: inicioHoy } },
    update: {
      horaInicioPrevista: "08:00",
      horaFinPrevista: "13:00",
      tarea: "Continuar impermeabilización",
    },
    create: {
      obraId: obra.id,
      trabajadorId: trabajador.id,
      fecha: inicioHoy,
      horaInicioPrevista: "08:00",
      horaFinPrevista: "13:00",
      tarea: "Continuar impermeabilización",
    },
  });

  console.log("Seed listo. Usuarios de prueba (password para todos: construite123):");
  console.log("  dueno@construite.com          -> portal admin + cliente + personal");
  console.log("  cliente@gonzalez.com          -> portal cliente (solo ve Edificio Las Heras)");
  console.log("  juan@construite.com           -> portal personal (solo ve su obra de hoy)");
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(() => prisma.$disconnect());
