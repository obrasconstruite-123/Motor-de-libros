# CONSTRUCTORA OS — Backend

Esqueleto de backend para CONSTRUI-TE: **un solo servidor, tres portales completamente
aislados** (Admin / Cliente / Personal), tal como se definió en el diseño. No es la
app completa — es la base de datos, la autenticación y el patrón de aislamiento ya
resueltos, con un endpoint representativo de cada portal totalmente funcional, listo
para que un programador extienda el resto siguiendo el mismo patrón.

## Por qué esto no podía ser solo frontend

Todo lo que se armó antes (el prototipo en React) corre en el navegador. Cualquier
"permiso" ahí es cosmético: con las herramientas de desarrollador, se ve todo. Acá el
filtrado de datos pasa **en el backend, en la consulta a la base de datos**, antes de
que el dato salga del servidor. Es la única forma de que el aislamiento sea real.

## Arquitectura

```
                    /api/auth/login  (compartido)
                            │
              ┌─────────────┼─────────────┐
              │             │             │
        /api/admin    /api/cliente   /api/personal
        (DUENO,       (DUENO,        (DUENO, GERENTE,
         GERENTE)      ADMINISTRADOR_  ENCARGADO,
                        CONSORCIO)      TRABAJADOR)
              │             │             │
              └─────────────┼─────────────┘
                            │
                    Una sola base de datos
                    (Postgres, ver prisma/schema.prisma)
```

- **Un solo login** (`POST /api/auth/login`) para los 3 portales. Lo que cambia es
  el `rol` que devuelve, y con eso el frontend de cada portal sabe qué mostrar.
- **Tres grupos de rutas separados** (`/api/admin`, `/api/cliente`, `/api/personal`),
  cada uno protegido por `requirePortal(...)` — ver `src/config/roles.js` para la
  matriz completa de qué rol entra a qué portal.
- **El filtrado de datos ocurre en la consulta**, no después. Por ejemplo, en
  `cliente.controller.js`, `misObras()` hace
  `where: { consorcio: { administracionId: req.user.administracionId } }` — un cliente
  jamás recibe filas de otra administración, ni siquiera cambiando IDs en la URL.
- **Selección explícita de campos** (`select: {...}`) en las rutas de cliente y
  personal: nunca se usa `include` genérico ahí, para que sea imposible filtrar por
  accidente un campo interno (margen, costos, teléfono de otro usuario, etc.) al
  agregar una columna nueva a la base más adelante.

## Setup local

```bash
cp .env.example .env
# completar DATABASE_URL con una Postgres local o de Railway/Supabase/Neon

npm install
npx prisma migrate dev --name init   # crea las tablas
npm run seed                          # carga 3 usuarios de prueba (uno por portal)
npm run dev                           # arranca en http://localhost:4000
```

Usuarios de prueba que carga el seed (password para todos: `construite123`):

| Email | Rol | Qué ve |
|---|---|---|
| `dueno@construite.com` | DUENO | los 3 portales |
| `cliente@gonzalez.com` | ADMINISTRADOR_CONSORCIO | solo Edificio Las Heras |
| `juan@construite.com` | TRABAJADOR | solo su obra asignada de hoy |

Probar login:

```bash
curl -X POST http://localhost:4000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"cliente@gonzalez.com","password":"construite123"}'
```

Con el `token` que devuelve, probar que el aislamiento funciona:

```bash
curl http://localhost:4000/api/cliente/obras \
  -H "Authorization: Bearer TOKEN_DEL_CLIENTE"
# devuelve la obra de Edificio Las Heras, con presupuestoTotal y saldo,
# pero SIN materiales, SIN margen, SIN costo real

curl http://localhost:4000/api/admin/obras \
  -H "Authorization: Bearer TOKEN_DEL_CLIENTE"
# 403 - el rol ADMINISTRADOR_CONSORCIO no tiene acceso al portal admin
```

## Deploy

Mismo patrón que ya venís usando con el bot de trading: **Railway**. Un servicio para
la API (este repo) + un plugin de Postgres. Variables de entorno: las de `.env.example`.
Correr `npx prisma migrate deploy` en el build/deploy step.

## Qué está completo y qué queda como patrón para extender

**Completo y funcional:**
- Login + JWT + verificación de usuario activo en cada request
- Matriz de permisos por rol/portal (`src/config/roles.js`)
- Portal admin: dashboard, CRM (administraciones), obras con cálculo financiero completo
- Portal cliente: consorcios, obras (con campos filtrados), fotos, reportar incidencia, aceptar presupuesto
- Portal personal: tareas del día, iniciar/finalizar trabajo con geolocalización, parte diario, registrar fotos

**Dejado como patrón a extender** (mismo estilo, mismo archivo, agregar función + ruta):
- CRUD completo de materiales, trabajadores, pagos desde el portal admin (hoy se gestionan
  vía Prisma Studio o se replica el patrón de `obras.controller`)
- Mensajería cliente ↔ admin (el modelo `Mensaje` ya existe en el schema)
- Notificaciones (push/email) cuando el cliente acepta un presupuesto o reporta una incidencia
- Refresh tokens (hoy el JWT expira a las 8hs y hay que loguearse de nuevo)

## Pendiente antes de producción (seguridad y robustez)

1. **Subida de fotos**: hoy `POST /obras/:id/fotos` solo guarda una URL. Falta el
   servicio de storage (S3, Cloudinary o similar) que genere URLs firmadas para que
   el celular suba la foto directo, sin pasar el archivo por este servidor.
2. **Rate limiting** en `/api/auth/login` (por ejemplo con `express-rate-limit`) para
   evitar fuerza bruta de contraseñas.
3. **Helmet** (`npm i helmet`) para headers de seguridad HTTP estándar.
4. **Validación de body** con una librería tipo `zod` en vez de los chequeos manuales
   actuales — hoy alcanza para el esqueleto, pero conviene antes de producción.
5. **HTTPS** obligatorio en producción (Railway lo da por defecto en su dominio).
6. **Auditoría**: loguear quién cambió el estado de una obra o aceptó un presupuesto
   (agregar un modelo `AuditLog` simple).
7. **WhatsApp Business API** real si se quiere automatizar el envío de presupuestos
   desde el propio backend (hoy, en el prototipo de frontend, se usa un link `wa.me`
   manual — funciona, pero no es programático).

## Estructura de carpetas

```
prisma/
  schema.prisma       modelo de datos completo
  seed.js             datos de prueba
src/
  config/
    prisma.js          cliente de Prisma (singleton)
    roles.js            matriz de permisos por rol/portal
  middleware/
    auth.js              requireAuth / requirePortal / requireRole
    errorHandler.js
  modules/
    auth/                login compartido
    admin/                portal DUENO / GERENTE
    cliente/              portal ADMINISTRADOR_CONSORCIO
    personal/             portal ENCARGADO / TRABAJADOR
  server.js              arma todo y levanta express
```
