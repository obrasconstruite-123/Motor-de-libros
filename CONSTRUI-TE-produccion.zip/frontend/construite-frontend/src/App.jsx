import { useEffect, useState } from "react";
import { api, getToken, clearToken } from "./api";
import LoginScreen from "./components/LoginScreen.jsx";
import AdminPortal from "./components/AdminPortal.jsx";
import ClientePortal from "./components/ClientePortal.jsx";
import PersonalPortal from "./components/PersonalPortal.jsx";

const PORTAL_LABEL = { admin: "Administración", cliente: "Portal cliente", personal: "Portal personal" };

export default function App() {
  const [sesion, setSesion] = useState(null); // { usuario, portalesDisponibles }
  const [portalActivo, setPortalActivo] = useState(null);
  const [cargandoSesion, setCargandoSesion] = useState(true);

  // Al abrir la app, si ya habia un token guardado, intenta recuperar la sesion
  // pegandole a /me en vez de asumir que el token sigue siendo valido.
  useEffect(() => {
    (async () => {
      const token = getToken();
      if (!token) return setCargandoSesion(false);
      try {
        const data = await api("/api/auth/me");
        // /me no devuelve portalesDisponibles, así que lo reconstruimos con la info de rol
        const rol = data.usuario.rol;
        const portales =
          rol === "DUENO" ? ["admin", "cliente", "personal"] :
          rol === "GERENTE" ? ["admin", "personal"] :
          rol === "ADMINISTRADOR_CONSORCIO" ? ["cliente"] :
          ["personal"];
        setSesion({ usuario: data.usuario, portalesDisponibles: portales });
        setPortalActivo(portales[0]);
      } catch {
        clearToken();
      } finally {
        setCargandoSesion(false);
      }
    })();
  }, []);

  const handleLogin = (data) => {
    setSesion(data);
    setPortalActivo(data.portalesDisponibles[0]);
  };

  const handleLogout = () => {
    clearToken();
    setSesion(null);
    setPortalActivo(null);
  };

  if (cargandoSesion) return null;
  if (!sesion) return <LoginScreen onLogin={handleLogin} />;

  return (
    <div style={{ maxWidth: 480, margin: "0 auto", minHeight: "100vh", display: "flex", flexDirection: "column" }}>
      <div style={{ padding: "14px 18px", display: "flex", justifyContent: "space-between", alignItems: "center", borderBottom: "1px solid var(--card-border)" }}>
        <div>
          <div style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: 15 }}>{sesion.usuario.nombre}</div>
          <div style={{ fontSize: 11, color: "var(--text-faint)" }}>{sesion.usuario.rol}</div>
        </div>
        <button onClick={handleLogout} className="btn-ghost" style={{ fontSize: 12, padding: "7px 12px" }}>Salir</button>
      </div>

      {sesion.portalesDisponibles.length > 1 && (
        <div style={{ display: "flex", gap: 4, padding: "10px 18px 0" }}>
          {sesion.portalesDisponibles.map((p) => (
            <button
              key={p}
              onClick={() => setPortalActivo(p)}
              style={{
                flex: 1, padding: "8px 6px", borderRadius: 9, border: "none", cursor: "pointer",
                fontSize: 12.5, fontWeight: 600,
                background: portalActivo === p ? "var(--jade)" : "var(--card)",
                color: portalActivo === p ? "#0e1512" : "var(--text-dim)",
              }}
            >
              {PORTAL_LABEL[p]}
            </button>
          ))}
        </div>
      )}

      <div style={{ flex: 1, overflowY: "auto" }}>
        {portalActivo === "admin" && <AdminPortal />}
        {portalActivo === "cliente" && <ClientePortal />}
        {portalActivo === "personal" && <PersonalPortal usuario={sesion.usuario} />}
      </div>
    </div>
  );
}
