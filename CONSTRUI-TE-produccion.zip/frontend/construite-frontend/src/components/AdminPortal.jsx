import { useEffect, useState } from "react";
import { api } from "../api";

const money = (n) => "$" + (Number(n) || 0).toLocaleString("es-AR");

export default function AdminPortal() {
  const [tab, setTab] = useState("dashboard");
  return (
    <div>
      <div style={{ display: "flex", gap: 4, padding: "10px 18px 0" }}>
        {[["dashboard", "Panel"], ["administraciones", "CRM"], ["obras", "Obras"]].map(([id, label]) => (
          <button
            key={id}
            onClick={() => setTab(id)}
            style={{
              flex: 1, padding: "7px 6px", borderRadius: 8, border: `1px solid var(--card-border)`,
              background: tab === id ? "var(--card)" : "transparent",
              color: tab === id ? "var(--jade-bright)" : "var(--text-faint)", fontSize: 12, fontWeight: 600,
            }}
          >
            {label}
          </button>
        ))}
      </div>
      {tab === "dashboard" && <Dashboard />}
      {tab === "administraciones" && <Administraciones />}
      {tab === "obras" && <Obras />}
    </div>
  );
}

function Dashboard() {
  const [data, setData] = useState(null);
  const [error, setError] = useState("");
  useEffect(() => {
    api("/api/admin/dashboard").then(setData).catch((e) => setError(e.message));
  }, []);
  if (error) return <div style={{ padding: 18 }}><p className="error-text">{error}</p></div>;
  if (!data) return <div style={{ padding: 18, color: "var(--text-faint)" }}>Cargando...</div>;

  return (
    <div style={{ padding: 18 }}>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
        <Stat label="Obras activas" value={data.obrasActivas} />
        <Stat label="Presupuestos pend." value={data.presupuestosPendientes} />
        <Stat label="Clientes" value={data.clientes} />
        <Stat label="Prospectos" value={data.prospectos} />
      </div>
      <div className="card" style={{ marginTop: 14 }}>
        <div className="mono" style={{ fontSize: 13, display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
          <span style={{ color: "var(--text-dim)", fontFamily: "var(--font-body)" }}>Facturado</span><span>{money(data.finanzas.facturado)}</span>
        </div>
        <div className="mono" style={{ fontSize: 13, display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
          <span style={{ color: "var(--text-dim)", fontFamily: "var(--font-body)" }}>Cobrado</span><span style={{ color: "var(--jade-bright)" }}>{money(data.finanzas.cobrado)}</span>
        </div>
        <div className="mono" style={{ fontSize: 14, fontWeight: 700, display: "flex", justifyContent: "space-between" }}>
          <span style={{ fontFamily: "var(--font-body)" }}>Ganancia estimada</span><span>{money(data.finanzas.ganancia)}</span>
        </div>
      </div>
    </div>
  );
}

function Stat({ label, value }) {
  return (
    <div className="card">
      <div style={{ fontSize: 11, color: "var(--text-dim)", fontWeight: 600, marginBottom: 4 }}>{label}</div>
      <div style={{ fontFamily: "var(--font-display)", fontSize: 22, fontWeight: 700 }}>{value}</div>
    </div>
  );
}

function Administraciones() {
  const [lista, setLista] = useState(null);
  const [error, setError] = useState("");
  const [form, setForm] = useState({ nombre: "", responsable: "", whatsapp: "" });
  const [guardando, setGuardando] = useState(false);

  const cargar = () => api("/api/admin/administraciones").then(setLista).catch((e) => setError(e.message));
  useEffect(() => { cargar(); }, []);

  const crear = async () => {
    if (!form.nombre.trim()) return;
    setGuardando(true);
    try {
      await api("/api/admin/administraciones", { method: "POST", body: form });
      setForm({ nombre: "", responsable: "", whatsapp: "" });
      cargar();
    } catch (err) {
      setError(err.message);
    } finally {
      setGuardando(false);
    }
  };

  if (!lista) return <div style={{ padding: 18, color: "var(--text-faint)" }}>Cargando...</div>;

  return (
    <div style={{ padding: 18 }}>
      <div className="card" style={{ marginBottom: 14 }}>
        <label className="label">Nueva administración</label>
        <input value={form.nombre} onChange={(e) => setForm({ ...form, nombre: e.target.value })} placeholder="Nombre" style={{ marginBottom: 8 }} />
        <input value={form.responsable} onChange={(e) => setForm({ ...form, responsable: e.target.value })} placeholder="Responsable" style={{ marginBottom: 8 }} />
        <input value={form.whatsapp} onChange={(e) => setForm({ ...form, whatsapp: e.target.value })} placeholder="WhatsApp" style={{ marginBottom: 10 }} />
        {error && <div className="error-text" style={{ marginBottom: 8 }}>{error}</div>}
        <button onClick={crear} className="btn-primary" disabled={guardando}>{guardando ? "Guardando..." : "Agregar"}</button>
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        {lista.map((a) => (
          <div key={a.id} className="card">
            <div style={{ fontWeight: 600, fontSize: 14 }}>{a.nombre}</div>
            <div style={{ fontSize: 12, color: "var(--text-dim)" }}>{a.consorcios.length} edificios · {a.estado}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

function Obras() {
  const [obras, setObras] = useState(null);
  const [error, setError] = useState("");
  useEffect(() => {
    api("/api/admin/obras").then(setObras).catch((e) => setError(e.message));
  }, []);
  if (error) return <div style={{ padding: 18 }}><p className="error-text">{error}</p></div>;
  if (!obras) return <div style={{ padding: 18, color: "var(--text-faint)" }}>Cargando...</div>;

  return (
    <div style={{ padding: 18, display: "flex", flexDirection: "column", gap: 8 }}>
      {obras.map((o) => (
        <div key={o.id} className="card">
          <div style={{ display: "flex", justifyContent: "space-between" }}>
            <span style={{ fontWeight: 600, fontSize: 14 }}>{o.numero}</span>
            <span className="pill" style={{ background: "var(--jade-dim)", color: "#fff" }}>{o.estado}</span>
          </div>
          <div style={{ fontSize: 12, color: "var(--text-dim)" }}>{o.consorcio?.nombre}</div>
          <div className="mono" style={{ fontSize: 12.5, marginTop: 8, display: "flex", justifyContent: "space-between" }}>
            <span>Total: {money(o.finanzas.totalPresupuesto)}</span>
            <span style={{ color: o.finanzas.gananciaEstimada >= 0 ? "var(--jade-bright)" : "var(--clay)" }}>
              Ganancia: {money(o.finanzas.gananciaEstimada)}
            </span>
          </div>
        </div>
      ))}
    </div>
  );
}
