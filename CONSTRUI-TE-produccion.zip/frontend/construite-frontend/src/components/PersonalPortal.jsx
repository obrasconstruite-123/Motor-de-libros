import { useEffect, useState } from "react";
import { api, getCurrentPosition } from "../api";

const money = (n) => "$" + (Number(n) || 0).toLocaleString("es-AR");

export default function PersonalPortal() {
  const [tareas, setTareas] = useState(null);
  const [error, setError] = useState("");
  const [parteActivo, setParteActivo] = useState(null); // { id, obraId } de la tarea en curso

  const cargar = async () => {
    try {
      const data = await api("/api/personal/mi-dia");
      setTareas(data);
    } catch (err) {
      setError(err.message);
    }
  };
  useEffect(() => { cargar(); }, []);

  const iniciar = async (obraId) => {
    setError("");
    try {
      const pos = await getCurrentPosition();
      const parte = await api(`/api/personal/obras/${obraId}/iniciar`, { method: "POST", body: pos });
      setParteActivo({ id: parte.id, obraId });
    } catch (err) {
      setError(err.message.includes("Geolocaliz") ? err.message : "No se pudo iniciar. " + err.message);
    }
  };

  const finalizar = async () => {
    if (!parteActivo) return;
    setError("");
    try {
      const pos = await getCurrentPosition();
      await api(`/api/personal/partes/${parteActivo.id}/finalizar`, { method: "POST", body: pos });
      setParteActivo({ ...parteActivo, finalizado: true });
    } catch (err) {
      setError(err.message);
    }
  };

  if (error && !tareas) return <div style={{ padding: 18 }}><p className="error-text">{error}</p></div>;
  if (!tareas) return <div style={{ padding: 18, color: "var(--text-faint)" }}>Cargando tu día...</div>;

  return (
    <div style={{ padding: 18 }}>
      <div style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: 20, marginBottom: 4 }}>Mi día</div>
      <div style={{ fontSize: 12.5, color: "var(--text-dim)", marginBottom: 18 }}>{tareas.length} tarea(s) asignada(s) hoy</div>

      {error && <div className="error-text" style={{ marginBottom: 14 }}>{error}</div>}

      {tareas.length === 0 ? (
        <div style={{ color: "var(--text-faint)", fontSize: 13.5, textAlign: "center", padding: "40px 20px" }}>
          No tenés tareas asignadas para hoy.
        </div>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {tareas.map((t) => {
            const enCurso = parteActivo?.obraId === t.obra.id && !parteActivo?.finalizado;
            const finalizado = parteActivo?.obraId === t.obra.id && parteActivo?.finalizado;
            return (
              <div key={t.id} className="card">
                <div style={{ fontWeight: 600, fontSize: 14.5 }}>{t.obra.consorcio.nombre}</div>
                <div style={{ fontSize: 12, color: "var(--text-dim)", marginTop: 2 }}>{t.obra.consorcio.direccion}</div>
                <div style={{ fontSize: 12, color: "var(--text-faint)", marginTop: 6 }}>
                  {t.horaInicioPrevista || "--"} – {t.horaFinPrevista || "--"}
                </div>
                {t.tarea && <div style={{ fontSize: 13, marginTop: 8 }}>{t.tarea}</div>}
                {t.obra.descripcion && <div style={{ fontSize: 12.5, color: "var(--text-dim)", marginTop: 3 }}>{t.obra.descripcion}</div>}

                <div style={{ marginTop: 12 }}>
                  {!parteActivo?.obraId || parteActivo.obraId !== t.obra.id ? (
                    <button onClick={() => iniciar(t.obra.id)} className="btn-primary">Iniciar trabajo</button>
                  ) : finalizado ? (
                    <div className="pill" style={{ background: "var(--jade-dim)", color: "#fff" }}>Trabajo finalizado</div>
                  ) : (
                    <button onClick={finalizar} className="btn-primary" style={{ background: "var(--clay)" }}>Finalizar trabajo</button>
                  )}
                </div>

                {finalizado && <ParteDiarioForm parteId={parteActivo.id} />}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function ParteDiarioForm({ parteId }) {
  const [tareas, setTareas] = useState("");
  const [material, setMaterial] = useState("");
  const [observaciones, setObservaciones] = useState("");
  const [estado, setEstado] = useState("Si");
  const [guardado, setGuardado] = useState(false);
  const [error, setError] = useState("");

  const guardar = async () => {
    setError("");
    try {
      await api(`/api/personal/partes/${parteId}`, {
        method: "PATCH",
        body: {
          tareasRealizadas: tareas.split(",").map((s) => s.trim()).filter(Boolean),
          materialUtilizado: material ? [{ material, cantidad: 1 }] : [],
          observaciones,
          estadoTrabajo: estado,
        },
      });
      setGuardado(true);
    } catch (err) {
      setError(err.message);
    }
  };

  if (guardado) return <div style={{ marginTop: 12, fontSize: 12.5, color: "var(--jade-bright)" }}>✓ Parte diario guardado</div>;

  return (
    <div style={{ marginTop: 14, borderTop: "1px solid var(--card-border)", paddingTop: 14 }}>
      <label className="label">Qué hiciste (separado por comas)</label>
      <input value={tareas} onChange={(e) => setTareas(e.target.value)} placeholder="Reparación, Pintura" style={{ marginBottom: 10 }} />
      <label className="label">Material utilizado</label>
      <input value={material} onChange={(e) => setMaterial(e.target.value)} placeholder="Ej: Cemento 2 bolsas" style={{ marginBottom: 10 }} />
      <label className="label">Observaciones</label>
      <textarea rows={3} value={observaciones} onChange={(e) => setObservaciones(e.target.value)} style={{ marginBottom: 10 }} />
      <label className="label">¿Trabajo terminado?</label>
      <select value={estado} onChange={(e) => setEstado(e.target.value)} style={{ marginBottom: 12 }}>
        <option value="Si">Sí</option>
        <option value="Parcial">Parcial</option>
        <option value="No">No</option>
      </select>
      {error && <div className="error-text" style={{ marginBottom: 10 }}>{error}</div>}
      <button onClick={guardar} className="btn-primary">Guardar parte diario</button>
    </div>
  );
}
