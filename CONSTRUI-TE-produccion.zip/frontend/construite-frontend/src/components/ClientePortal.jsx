import { useEffect, useState } from "react";
import { api } from "../api";

const money = (n) => "$" + (Number(n) || 0).toLocaleString("es-AR");
const ESTADO_COLOR = {
  "Presupuesto": "#c19a3c", "Aprobada": "#6b8fb0", "Programada": "#8f6bb0",
  "En ejecución": "var(--clay)", "Terminada": "var(--jade)", "Suspendida": "var(--text-faint)",
};

export default function ClientePortal() {
  const [obras, setObras] = useState(null);
  const [consorcios, setConsorcios] = useState([]);
  const [error, setError] = useState("");
  const [mostrarForm, setMostrarForm] = useState(false);

  const cargar = async () => {
    try {
      const [o, c] = await Promise.all([api("/api/cliente/obras"), api("/api/cliente/consorcios")]);
      setObras(o);
      setConsorcios(c);
    } catch (err) {
      setError(err.message);
    }
  };
  useEffect(() => { cargar(); }, []);

  const aceptar = async (id) => {
    try {
      await api(`/api/cliente/obras/${id}/aceptar`, { method: "POST" });
      cargar();
    } catch (err) {
      setError(err.message);
    }
  };

  if (error && !obras) return <div style={{ padding: 18 }}><p className="error-text">{error}</p></div>;
  if (!obras) return <div style={{ padding: 18, color: "var(--text-faint)" }}>Cargando...</div>;

  return (
    <div style={{ padding: 18 }}>
      <div style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: 20, marginBottom: 4 }}>Mis obras</div>
      <div style={{ fontSize: 12.5, color: "var(--text-dim)", marginBottom: 16 }}>{consorcios.length} edificio(s) a cargo</div>

      <button onClick={() => setMostrarForm(true)} className="btn-ghost" style={{ marginBottom: 16, width: "100%" }}>
        + Reportar un problema
      </button>
      {mostrarForm && <IncidenciaForm consorcios={consorcios} onDone={() => setMostrarForm(false)} />}

      {obras.length === 0 ? (
        <div style={{ color: "var(--text-faint)", fontSize: 13.5, textAlign: "center", padding: "40px 20px" }}>
          Todavía no hay obras registradas en tus edificios.
        </div>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {obras.map((o) => (
            <div key={o.id} className="card">
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                <div>
                  <div style={{ fontWeight: 600, fontSize: 14.5 }}>{o.numero}</div>
                  <div style={{ fontSize: 12, color: "var(--text-faint)" }}>{o.edificio}</div>
                </div>
                <span className="pill" style={{ background: (ESTADO_COLOR[o.estado] || "#888") + "22", color: ESTADO_COLOR[o.estado] || "#888" }}>
                  {o.estado}
                </span>
              </div>
              {o.descripcion && <div style={{ fontSize: 13, marginTop: 8 }}>{o.descripcion}</div>}

              {o.estado !== "Presupuesto" && (
                <div style={{ marginTop: 10 }}>
                  <div style={{ height: 6, background: "var(--bg-elevated)", borderRadius: 4, overflow: "hidden" }}>
                    <div style={{ width: `${o.avancePct}%`, height: "100%", background: "var(--jade)" }} />
                  </div>
                  <div style={{ fontSize: 11, color: "var(--text-faint)", marginTop: 3 }}>{o.avancePct}% completado</div>
                </div>
              )}

              <div className="mono" style={{ fontSize: 12.5, marginTop: 10, display: "flex", justifyContent: "space-between" }}>
                <span style={{ color: "var(--text-dim)" }}>Total: {money(o.presupuestoTotal)}</span>
                {o.saldo > 0 && <span style={{ color: "var(--clay)" }}>saldo {money(o.saldo)}</span>}
              </div>

              {o.estado === "Presupuesto" && (
                <button onClick={() => aceptar(o.id)} className="btn-primary" style={{ marginTop: 12 }}>
                  Aceptar presupuesto
                </button>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function IncidenciaForm({ consorcios, onDone }) {
  const [consorcioId, setConsorcioId] = useState(consorcios[0]?.id || "");
  const [problema, setProblema] = useState("");
  const [enviado, setEnviado] = useState(false);
  const [error, setError] = useState("");

  const enviar = async () => {
    setError("");
    try {
      await api("/api/cliente/incidencias", { method: "POST", body: { consorcioId, problema } });
      setEnviado(true);
      setTimeout(onDone, 1200);
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div className="card" style={{ marginBottom: 16 }}>
      {enviado ? (
        <div style={{ color: "var(--jade-bright)", fontSize: 13.5 }}>✓ Reporte enviado. Te contactamos a la brevedad.</div>
      ) : (
        <>
          <label className="label">Edificio</label>
          <select value={consorcioId} onChange={(e) => setConsorcioId(e.target.value)} style={{ marginBottom: 10 }}>
            {consorcios.map((c) => <option key={c.id} value={c.id}>{c.nombre}</option>)}
          </select>
          <label className="label">¿Qué está pasando?</label>
          <textarea rows={3} value={problema} onChange={(e) => setProblema(e.target.value)} placeholder="Ej: hay humedad en el 4B" style={{ marginBottom: 10 }} />
          {error && <div className="error-text" style={{ marginBottom: 10 }}>{error}</div>}
          <button onClick={enviar} className="btn-primary">Enviar</button>
        </>
      )}
    </div>
  );
}
