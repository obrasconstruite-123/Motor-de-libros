# CONSTRUI-TE — Frontend web (sin App Store)

Los 3 portales (Admin, Cliente, Personal) en una sola app web. Detecta el rol al
loguearse y muestra el portal correspondiente — si el usuario tiene acceso a más
de uno (como el Dueño), aparecen pestañas arriba para cambiar entre ellos.

Cámara y GPS funcionan igual que en una app nativa: el navegador los pide con
permiso (esto ya está resuelto en `PersonalPortal.jsx`, usa
`navigator.geolocation`). Lo único que **no** hace un sitio web es sacarte fotos
en segundo plano sin tener la pestaña abierta — para este uso (marcar entrada/salida
y sacar fotos durante la visita) no hace falta.

## Puesta en marcha, paso a paso

### 1. Backend primero
Este frontend no sirve de nada sin la API corriendo. Si todavía no la desplegaste:
1. Subí la carpeta `construite-backend` a un repo de GitHub.
2. Entrá a [railway.app](https://railway.app), "New Project" → "Deploy from GitHub repo".
3. Agregá un plugin de PostgreSQL (Railway te arma la `DATABASE_URL` solo).
4. Copiá las variables de `.env.example` a las variables de entorno del servicio.
5. En "Deploy" agregá el comando `npx prisma migrate deploy && npm run seed && npm start`
   (sacá `&& npm run seed` después del primer deploy, es solo para cargar los usuarios de prueba una vez).
6. Copiá la URL que te da Railway (algo como `https://construite-backend-production.up.railway.app`).

### 2. Este frontend
```bash
cp .env.example .env
# pegar ahi la URL de Railway del paso anterior, en VITE_API_URL

npm install
npm run dev        # para probarlo en tu compu, en localhost:5173
```

Para probarlo desde el celular en la misma red mientras desarrollás:
```bash
npm run dev -- --host
# te da una URL tipo http://192.168.x.x:5173 para abrir desde el celular
```

### 3. Publicarlo de verdad (gratis, sin store)
```bash
npm run build       # genera la carpeta dist/
```
Subí la carpeta a **Vercel** o **Netlify** (ambos tienen plan gratis y detectan
Vite automáticamente si conectás el repo de GitHub). En 2 minutos te dan una URL
tipo `https://construite.vercel.app` — esa es la app, ya en producción, sin
esperar revisión de nadie.

No te olvides de configurar `VITE_API_URL` como variable de entorno en Vercel/Netlify
también (ahí la interfaz te la pide al conectar el repo).

### 4. "Instalarla" en el celular sin App Store
Una vez que está publicada:
- **Android (Chrome)**: entrar a la URL → menú (⋮) → "Agregar a pantalla de inicio".
- **iPhone (Safari)**: entrar a la URL → botón compartir → "Agregar a pantalla de inicio".

Con el `manifest.json` y los meta tags que ya están en `index.html`, queda con
ícono propio y abre a pantalla completa (sin la barra del navegador), muy parecido
a una app nativa instalada. Esto es lo que se llama PWA — no pasa por ningún
store, no hay revisión, no hay costo anual.

## Qué cambia respecto del prototipo anterior

El artifact que armamos en Claude.ai guardaba todo en `window.storage` (solo vos
lo veías, solo en esa conversación). **Este** frontend le pega de verdad a la API
que desplegaste — login real con contraseña, y cada usuario ve exactamente lo que
su rol permite, filtrado en el servidor.

## Nota sobre las fotos de obra

El backend ya tiene el endpoint `POST /api/personal/obras/:id/fotos`, pero
todavía falta conectar un servicio de storage real (Cloudinary o S3) para que la
foto se suba desde el celular. Está documentado como pendiente en el README del
backend — es la única pieza de la Fase 3/4 que falta antes de usar esto en el día
a día con fotos de antes/durante/después.

## Estructura

```
src/
  api.js                 fetch wrapper + manejo de token + geolocalizacion
  App.jsx                 sesion, selector de portal, logout
  components/
    LoginScreen.jsx
    AdminPortal.jsx        dashboard, CRM, obras
    ClientePortal.jsx       mis obras, aceptar presupuesto, reportar incidencia
    PersonalPortal.jsx      mi dia, iniciar/finalizar trabajo, parte diario
```
